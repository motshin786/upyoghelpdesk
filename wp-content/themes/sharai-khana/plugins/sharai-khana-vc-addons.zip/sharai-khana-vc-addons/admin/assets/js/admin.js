(function ($) {
    "use strict";

    $(function () {

        // Place your administration-specific JavaScript here


        if ($('#vc_license-activation-notice').length > 0) {
            $('#vc_license-activation-notice').remove();
        }

    });

}(jQuery));